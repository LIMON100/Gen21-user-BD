package com.gen21.home_service

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
