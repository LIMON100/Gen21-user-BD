import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../common/log_data.dart';
import '../../../models/message_model.dart';
import '../../global_widgets/circular_loading_widget.dart';
import '../../global_widgets/notifications_button_widget.dart';
import '../controllers/messages_controller.dart';
import '../widgets/message_item_widget.dart';

class MessagesView extends GetView<MessagesController> {
  Widget conversationsList() {
    return Obx(
      () {
        printWrapped("nsjkdnkjfsan in MessagesView class isHaveToShowProgressView ${controller.isHaveToShowProgressView.value} controller.messages.length: ${controller.messages.length} controller.messages.toString: ${controller.messages.toString()}");
        if(controller.isHaveToShowProgressView.value == true){
          print("sdbfhbahsmessage in if");
          return Container(
            width: 200,
            height: 200,
            color: Colors.yellow,
            child: CircularLoadingWidget(
              height: Get.height,
            ),
          );
        }
        else if(controller.messages.isNotEmpty) {
          var _messages = controller.messages;
          return ListView.separated(
              physics: AlwaysScrollableScrollPhysics(),
              controller: controller.scrollController,
              itemCount: _messages.length,
              separatorBuilder: (context, index) {
                return SizedBox(height: 7);
              },
              shrinkWrap: true,
              primary: false,
              itemBuilder: (context, index) {
                print("fdafgagtaf index: ${index}");
                return MessageItemWidget(
                    message: controller.messages.elementAt(index),
                onDismissed: (conversation) async {
                await controller.deleteMessage(controller.messages.elementAt(index));
                },
                );
                // if (index == controller.messages.length - 1) {
                //   return Obx(() {
                //     return Container(
                //       color: Colors.blue,
                //       child: Padding(
                //         padding: const EdgeInsets.all(8.0),
                //         child: new Center(
                //           child: new Opacity(
                //             opacity: controller.isLoading.value ? 1 : 0,
                //             child: new CircularProgressIndicator(),
                //           ),
                //         ),
                //       ),
                //     );
                //   });
                // } else {
                //   return MessageItemWidget(
                //     message: controller.messages.elementAt(index),
                //     onDismissed: (conversation) async {
                //       await controller.deleteMessage(controller.messages.elementAt(index));
                //     },
                //   );}
              });
        } else {
          return CircularLoadingWidget(
            height: Get.height,
            onCompleteText: "Messages List Empty".tr,
          );
        }
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Chats".tr,
          style: Get.textTheme.headline6,
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        leading: new IconButton(
          icon: new Icon(Icons.sort, color: Get.theme.hintColor),
          onPressed: () => {Scaffold.of(context).openDrawer()},
        ),
        actions: [NotificationsButtonWidget()],
      ),
      body: RefreshIndicator(
          onRefresh: () async {
            controller.messages.clear();
            controller.lastDocument = new Rx<DocumentSnapshot>(null);
            await controller.listenForMessages();
          },
          child: controller.isLoading.value? Padding(
            padding: const EdgeInsets.all(8.0),
            child: new Center(
              child: new Opacity(
                opacity: controller.isLoading.value ? 1 : 0,
                child: new CircularProgressIndicator(),
              ),
            ),
          ): conversationsList()),
    );
  }
}
