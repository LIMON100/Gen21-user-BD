String predefinedCountryCode = "+88";
String countryCodeBd = "+88";
String countryCodeAu = "+61";
//eWay test url
// String eWayBaseUrl = "https://api.sandbox.ewaypayments.com/";
// String eWayDoneDoneUrl = "secure-au.sandbox.ewaypayments.com/sharedpage/sharedpayment/Result";
// String ewayKey = '60CF3ClcGwNUMKFWjFtycl2VtkXkwieJ4K0VJh25OpSSDMnL4yQdFLsrCa6fLOVdyCoVl3';
// String ewayPassword = 'WJTtxJCT';

//eWay live url
String eWayBaseUrl = "https://api.ewaypayments.com/";
String eWayDoneDoneUrl = "secure.ewaypayments.com/sharedpage/sharedpayment/Result";
String ewayKey = "44DD7AiUXNIMQRXxnoYrrT3XUleIxf4FlNerXf4kflldYFEtEKfyxG0bp8WIqmxkZoKr5a";
String ewayPassword = "h4xoK7Nz";
