import 'dart:developer';
import 'dart:ffi';
import 'package:get/get.dart';
import '../../../../common/log_data.dart';
import '../../../../common/ui.dart';
import '../../../models/search_suggestion_model.dart';
import '../../../models/service_details_model.dart';
import '../../../models/service_model.dart';
import '../../../repositories/service_repository.dart';

class ServiceController extends GetxController {
  final service = GService().obs;
  final currentSlide = 0.obs;
  final heroTag = ''.obs;
  ServiceRepository _serviceRepository;
  List<String> tabs = ["Services", "Description", "Faq"];
  final selectedTab = 0.obs;
  String categoryId;

  final serviceDetails = ServiceDetails().obs;


  ServiceController() {
    print("sjdnfhsba ServiceController() ${selectedTab.value}");
    _serviceRepository = new ServiceRepository();
  }

  @override
  void onInit() async {
    print("sjdnfhsba onInit() ${selectedTab.value}");

    var arguments = Get.arguments as Map<String, dynamic>;
    print("KYToitojuu argmnts ServiceController ${arguments.toString()}");
    heroTag.value = arguments['heroTag'] as String;
    // _searchSuggestion = arguments['searchSuggestion'] as SearchSuggestion;
    categoryId = arguments['category_id'];
    print("KYToitojuu categoryId ServiceController ${categoryId}");
    super.onInit();
  }

  @override
  void onReady() async {
    print("fsjfsads0");
    await refreshEService();
    super.onReady();
  }

  Future refreshEService({bool showMessage = false}) async {
    print("fsjfsads1");

    // getService("1");

    getService(categoryId);
    if (showMessage) {
      // Get.showSnackbar(Ui.SuccessSnackBar(message: eService.value.name + " " + "page refreshed successfully".tr));
    }
  }

  Future getService(String id) async {
    print("fsjfsads3");

    try {
      service.value = await _serviceRepository.get(id);
      printWrapped("sdnkjfnajk response data: ${service.value.toString()}");
    } catch (e) {
      Get.showSnackbar(Ui.ErrorSnackBar(message: e.toString()));
    }
  }

  // Future getServiceDetails(String id) async {
  //   print("fsjfsads3");
  //
  //   try {
  //     serviceDetails.value = await _serviceRepository.getServiceDetails(id);
  //     print("sdhbfhbash ${serviceDetails.value.toString()}");
  //   } catch (e) {
  //     Get.showSnackbar(Ui.ErrorSnackBar(message: e.toString()));
  //   }
  // }

  void changeTab(int id) async {
    selectedTab.value = id;
  }

}
