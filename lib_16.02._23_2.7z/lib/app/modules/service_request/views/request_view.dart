import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:home_services/app/modules/service_request/views/providers_list_widget.dart';
import '../../../../common/place_picker_dialog.dart';
import '../../../../common/ui.dart';
import '../../../models/address_model.dart';
import '../../../providers/laravel_provider.dart';
import '../../../routes/app_routes.dart';
import '../../../services/settings_service.dart';
import '../../cart/controller/add_to_cart_controller.dart';
import '../../global_widgets/circular_loading_widget.dart';
import '../../global_widgets/tab_bar_widget.dart';
import '../controllers/RequestController.dart';
import 'package:intl/intl.dart' show DateFormat;

class RequestView extends GetView<RequestController> {
  final AddToCartController _addToCartController = Get.put(AddToCartController());

  @override
  Widget build(BuildContext context) {
    var orderTimeType = controller.orderTimeType;
    var orderRequestType = controller.orderRequestType;

    var selectedOrderTimeType = controller.selectedOrderTimeType;
    var selectedOrderRequestType = controller.selectedOrderRequestType;

    print("fsjfsads0001 ${orderTimeType.toString()}");
    print("fsjfsads0001 ${orderRequestType.toString()}");
    return Scaffold(
      body: Container(
        color: Colors.grey.withOpacity(.15),
        child: RefreshIndicator(
            onRefresh: () async {
              Get.find<LaravelApiClient>().forceRefresh();
              controller.refreshRequest(showMessage: true);
              Get.find<LaravelApiClient>().unForceRefresh();
            },
            child: CustomScrollView(
              primary: true,
              shrinkWrap: false,
              slivers: <Widget>[
                SliverAppBar(
                  leading: GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.black,
                    ),
                  ),
                  backgroundColor: Colors.white,
                  title: Container(
                    width: double.infinity,
                    alignment: Alignment.topLeft,
                    child: Text(
                      'Request'.tr,
                      style: TextStyle(fontSize: 16, color: Colors.black),
                    ),
                  ),
                  // backgroundColor: scrolled ? Colors.blue : Colors.red,
                  pinned: true,
                ),
                SliverToBoxAdapter(
                  child: Container(
                    padding: EdgeInsets.only(left: 15, right: 15, top: 15),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(
                          children: [
                            Icon(Icons.place_outlined, color: Get.theme.colorScheme.secondary),
                            Text(
                              "Your Address",
                              style: TextStyle(color: Get.theme.colorScheme.secondary, fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                          ],
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Obx(() {
                              print("ksdjndsa ");
                              return Flexible(child: Container(padding: EdgeInsets.only(left: 5), child: Text(controller.currentAddress?.address ?? "Loading...".tr, style: Get.textTheme.bodyText2)));
                            }),
                            GestureDetector(
                              onTap: () {
                                // Get.toNamed(Routes.SETTINGS_ADDRESS_PICKER);
                                showPlacePicker();
                              },
                              child: Container(
                                margin: EdgeInsets.only(left: 15),
                                padding: EdgeInsets.only(left: 10, right: 10, top: 10, bottom: 10),
                                decoration: BoxDecoration(
                                  color: Get.theme.colorScheme.secondary.withOpacity(0.30),
                                  borderRadius: BorderRadius.all(Radius.circular(6)),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.gps_fixed,
                                      color: Get.theme.colorScheme.secondary,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Change",
                                      style: TextStyle(color: Get.theme.colorScheme.secondary),
                                    )
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Obx(() {
                          if (controller.addresses.isEmpty) {
                            return TabBarLoadingWidget();
                          } else {
                            print("sdnfjsfsdan  Get.find<SettingsService>().address: ${controller.currentAddress?.address}");
                            if (controller.currentAddress?.address == null) {
                              final _address = controller.addresses.elementAt(0);
                              Get.find<SettingsService>().address.value = _address;
                              print("sdnfjsfsdan  Get.find<SettingsService>().address.value: ${Get.find<SettingsService>().address.value}");
                            }
                            return TabBarWidget(
                              initialSelectedId: "0",
                              tag: 'addresses',
                              tabs: List.generate(controller.addresses.length, (index) {
                                final _address = controller.addresses.elementAt(index);
                                return ChipWidget(
                                  tag: 'addresses',
                                  text: _address.getDescription,
                                  id: index,
                                  onSelected: (id) {
                                    Get.find<SettingsService>().address.value = _address;
                                    controller.refreshRequest(showMessage: true);
                                  },
                                );
                              }),
                            );
                          }
                        }),

                        // SizedBox(height: 15),
                        // Row(
                        //   children: [
                        //     SizedBox(width: 20),
                        //     Icon(Icons.place_outlined, color: Get.theme.focusColor),
                        //     SizedBox(width: 15),
                        //     Expanded(
                        //       child: Obx(() {
                        //         return Text(controller.currentAddress?.address ?? "Loading...".tr, style: Get.textTheme.bodyText2);
                        //       }),
                        //     ),
                        //     SizedBox(width: 20),
                        //   ],
                        // ),
                        SizedBox(
                          height: 20,
                        ),
                        buildNoteInputField(),
                        SizedBox(
                          height: 20,
                        ),
                        buildCouponField(),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          padding: EdgeInsets.only(left: 14, right: 7),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              // border: Border.all(
                              //   color: Get.theme.colorScheme.secondary.withOpacity(.50),
                              // ),
                              borderRadius: BorderRadius.circular(4)),
                          child:
                              // Padding(
                              //   padding: EdgeInsets.all(1),
                              //   child:
                              DropdownButtonFormField(
                                  hint: Text("Select Time Schedule".tr),
                                  iconEnabledColor: Get.theme.colorScheme.secondary,
                                  decoration: InputDecoration(
                                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                                    disabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                                    // decoration: ShapeDecoration(
                                    //   shape: RoundedRectangleBorder(
                                    //     side: BorderSide(width: 1.0, style: BorderStyle.solid),
                                    //     borderRadius: BorderRadius.all(Radius.circular(5.0)),
                                    //   ),
                                    // ),
                                  ),
                                  dropdownColor: Colors.white,
                                  // value: controller.selectedOrderTimeType.value,
                                  // onChanged: (String newValue) {
                                  //   // selectedOrderTimeType.value = "";
                                  // },
                                  onChanged: (value) {
                                    print("ksdfnasj $value");
                                    controller.selectedOrderTimeType.value = value;
                                    if (value.toString() == "As Soon As Possible") {
                                      controller.bookingAt.value = DateTime.now();
                                    }
                                  },
                                  items: orderTimeType),

                          // ),
                        ),
                        Obx(() {
                          DateTime bookingAt = controller.bookingAt.value;
                          return selectedOrderTimeType == "Schedule An Order"
                              ? Column(
                                  children: [
                                    Divider(
                                      height: 1,
                                      color: Colors.grey.withOpacity(.15),
                                    ),
                                    Container(
                                      color: Colors.white,
                                      padding: EdgeInsets.only(top: 10, bottom: 10),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Select Date",
                                                style: TextStyle(color: Colors.grey.shade700),
                                              ),
                                              SizedBox(
                                                height: 5,
                                              ),
                                              GestureDetector(
                                                onTap: () {
                                                  controller.showMyDatePicker(context);
                                                },
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Icon(Icons.date_range_outlined),
                                                    SizedBox(
                                                      width: 5,
                                                    ),
                                                    Text('${DateFormat.yMMMMEEEEd(Get.locale.toString()).format(bookingAt)}')
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                          SizedBox(
                                            width: 40,
                                          ),
                                          Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Select Time",
                                                style: TextStyle(color: Colors.grey.shade700),
                                              ),
                                              SizedBox(
                                                height: 5,
                                              ),
                                              GestureDetector(
                                                onTap: () {
                                                  controller.showMyTimePicker(context);
                                                },
                                                child: Row(
                                                  crossAxisAlignment: CrossAxisAlignment.center,
                                                  children: [
                                                    Icon(Icons.watch_later_outlined),
                                                    SizedBox(
                                                      width: 5,
                                                    ),
                                                    Text("${DateFormat('HH:mm', Get.locale.toString()).format(bookingAt)}")
                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                )
                              : Container();
                        }),
                        SizedBox(
                          height: 20,
                        ),
                        Container(
                          padding: EdgeInsets.only(left: 14, right: 7),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              // border: Border.all(
                              //   color: Get.theme.colorScheme.secondary.withOpacity(.50),
                              // ),
                              borderRadius: BorderRadius.circular(4)),
                          child:
                              // Padding(
                              //   padding: EdgeInsets.all(1),
                              //   child:
                              DropdownButtonFormField(
                                  hint: Text("Select Request Type".tr),
                                  iconEnabledColor: Get.theme.colorScheme.secondary,
                                  decoration: InputDecoration(
                                    enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                                    disabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                                    focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white)),
                                    // decoration: ShapeDecoration(
                                    //   shape: RoundedRectangleBorder(
                                    //     side: BorderSide(width: 1.0, style: BorderStyle.solid),
                                    //     borderRadius: BorderRadius.all(Radius.circular(5.0)),
                                    //   ),
                                    // ),
                                  ),
                                  dropdownColor: Colors.white,
                                  // value: controller.selectedOrderRequestType.value,
                                  // onChanged: (String newValue) {
                                  //   // selectedOrderTimeType.value = "";
                                  // },
                                  onChanged: (value) {
                                    print("ksdfnasj $value");
                                    controller.selectedOrderRequestType.value = value;
                                  },
                                  items: orderRequestType),

                          // ),
                        ),
                        Obx(() {
                          return selectedOrderRequestType == "Choose Provider Manually" && controller.providersData.length > 0
                              ? Container(
                                  margin: EdgeInsets.only(top: 15, bottom: 15),
                                  child: MediaQuery.removePadding(
                                    context: context,
                                    removeTop: true,
                                    child: ListView.builder(
                                      primary: false,
                                      shrinkWrap: true,
                                      scrollDirection: Axis.vertical,
                                      itemBuilder: (_, index) {
                                        return Container(
                                            child: ProvidersListWidget(
                                          // data: controller.providersDataWithServiceName[index],
                                          data: controller.providersData[index],
                                          serviceIndex: index,
                                        ));
                                      },
                                      itemCount: controller.providersData.length,
                                    ),
                                  ),
                                )
                              : Container();
                        }),
                      ],
                    ),
                  ),
                ),
              ],
            )),
      ),
      bottomNavigationBar: Container(
          padding: EdgeInsets.only(left: 15, right: 15),
          height: 50,
          // color: Colors.white,
          decoration: BoxDecoration(
            color: Colors.white,
            // borderRadius: BorderRadius.circular(20),
            boxShadow: [
              // BoxShadow(
              //   color: Colors.grey.shade900,
              //   blurRadius: 4,
              //   offset: Offset(4, 8), // Shadow position
              // ),
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 5,
                blurRadius: 7,
                offset: Offset(0, 3), // changes position of shadow
              ),
            ],
          ),
          child: Obx(() {
            return Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Text(
                      "${_addToCartController.addToCartData.length} ${_addToCartController.addToCartData.length > 1 ? "Services".tr : "Service".tr}",
                      style: TextStyle(fontSize: 14, color: Colors.grey.shade500, fontWeight: FontWeight.w100),
                    ),
                    Text(
                      " | ",
                      style: TextStyle(fontSize: 20, color: Colors.grey.shade500, fontWeight: FontWeight.normal),
                    ),
                    Text(
                      "${_addToCartController.totalAmount().toStringAsFixed(3)}",
                      style: TextStyle(fontSize: 14, color: Colors.grey.shade500, fontWeight: FontWeight.w100),
                    ),
                  ],
                ),
                controller.isSubmitOrderLoading.value == true
                    ? CircularProgressIndicator()
                    : InkWell(
                        onTap: () {
                          // Get.toNamed(Routes.SERVICE_REQUEST);
                          // bottomSheetDialog(context);

                          if (Get.find<SettingsService>().address.value.isUnknown()) {
                            Get.showSnackbar(Ui.ErrorSnackBar(message: "Please set your location"));
                          } else {
                            if (selectedOrderRequestType != "Choose Provider Manually") {
                              controller.submitBookingRequest(_addToCartController.addToCartData);
                            }
                            if (selectedOrderRequestType == "Choose Provider Manually" && controller.providersData.length > 0) {
                              controller.validateManualBookingRequest(_addToCartController.addToCartData);
                            }
                          }
                        },
                        child: Container(
                          padding: EdgeInsets.only(left: 20, right: 20, top: 10, bottom: 10),
                          decoration: BoxDecoration(
                            color: Get.theme.colorScheme.secondary,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                          child: Text("Request".tr, style: (TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: Colors.white))),
                        ),
                      )
              ],
            );
          })),
    );
  }

  Widget buildNoteInputField() {
    return Hero(
      tag: Get.arguments ?? '',
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 12, vertical: 0),
        decoration: BoxDecoration(
            border: Border.all(
              color: Get.theme.colorScheme.secondary.withOpacity(.50),
            ),
            borderRadius: BorderRadius.circular(4)),
        child: Container(
          child: Row(
            children: <Widget>[
              InkWell(
                onTap: () {
                  Get.back();
                },
                child: Padding(
                  padding: const EdgeInsets.only(right: 12, left: 0),
                  child: Icon(
                    Icons.sticky_note_2_outlined,
                    color: Get.theme.colorScheme.secondary,
                    size: 28,
                  ),
                ),
              ),
              Expanded(
                // child: Material(
                child: TextField(
                  controller: controller.noteEditingController,
                  autofocus: false,
                  // onChanged:  controller.onChangeHandler,
                  // clipBehavior: HitTestBehavior.translucent,
                  style: Get.textTheme.bodyText2,
                  onSubmitted: (value) {
                    // controller.searchEServices(keywords: value);
                  },
                  cursorColor: Get.theme.focusColor,
                  decoration: Ui.getInputDecoration(
                    hintText: "Write here if you have any extra requirements.".tr,
                  ),
                ),
                // ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget buildCouponField() {
    final _formKey = GlobalKey<FormState>();
    return Form(
      key: _formKey,
      child: Column(
        children: [
          Hero(
            tag: Get.arguments ?? '',
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 12, vertical: 0),
              decoration: BoxDecoration(
                  border: Border.all(
                    color: Get.theme.colorScheme.secondary.withOpacity(.50),
                  ),
                  borderRadius: BorderRadius.circular(4)),
              child: Container(
                child: Row(
                  children: <Widget>[
                    InkWell(
                      onTap: () {
                        Get.back();
                      },
                      child: Padding(
                        padding: const EdgeInsets.only(right: 12, left: 0),
                        child: Icon(
                          Icons.local_offer_outlined,
                          color: Get.theme.colorScheme.secondary,
                          size: 28,
                        ),
                      ),
                    ),
                    Expanded(
                      // child: Material(
                      child: TextFormField(
                        controller: controller.couponEditingController,
                        // onChanged:  controller.onChangeHandler,
                        // clipBehavior: HitTestBehavior.translucent,
                        style: Get.textTheme.bodyText2,
                        // onSubmitted: (value) {
                        //   // controller.searchEServices(keywords: value);
                        // },
                        // onChanged: (input) => controller.oldPassword.value = input,
                        // validator: (input) => input.length < 1 ? "Enter a valid promo code".tr : null,
                        autofocus: false,
                        cursorColor: Get.theme.focusColor,
                        decoration: Ui.getInputDecoration(
                          hintText: "Enter your coupon here.".tr,
                        ),
                      ),
                      // ),
                    ),
                    Obx(() {
                      return controller.isLoading.value
                          ? CircularProgressIndicator()
                          : Container(
                              margin: EdgeInsets.only(left: 15),
                              padding: EdgeInsets.only(left: 15, right: 15, top: 7, bottom: 7),
                              decoration: BoxDecoration(
                                color: Get.theme.colorScheme.secondary.withOpacity(0.30),
                                borderRadius: BorderRadius.all(Radius.circular(20)),
                              ),
                              child: GestureDetector(
                                onTap: () {
                                  // if (_formKey.currentState.validate()) {
                                  // If the form is valid, display a snackbar. In the real world,
                                  // you'd often call a server or save the information in a database.
                                  if (controller.couponEditingController.text.trim().length > 1) {
                                    controller.validateCoupon();
                                  } else {
                                    Get.showSnackbar(Ui.ErrorSnackBar(message: "You haven't entered any coupon code!"));
                                  }

                                  // }
                                },
                                child: Text(
                                  "Apply",
                                  style: TextStyle(color: Get.theme.colorScheme.secondary),
                                ),
                              ),
                            );
                    })
                  ],
                ),
              ),
            ),
          ),
          Obx(() {
            return controller.coupon.value != null && controller.coupon.value.code != null
                ? Container(
                    margin: EdgeInsets.only(top: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "Applied Coupon: ",
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 12,
                          ),
                        ),
                        InkWell(
                          onTap: () {
                            controller.clearCoupon();
                          },
                          child: Container(
                            // margin: EdgeInsets.only(top: 10),
                            child: Stack(
                              children: [
                                Positioned(
                                  right: 0,
                                  top: 0,
                                  child: GestureDetector(
                                    // behavior: HitTestBehavior.translucent,
                                    child: InkWell(
                                      child: Container(
                                        child: Icon(
                                          Icons.cancel,
                                          size: 20,
                                          color: Colors.grey,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  clipBehavior: Clip.none,
                                  padding: EdgeInsets.only(left: 20, right: 20, top: 7, bottom: 7),
                                  decoration: BoxDecoration(
                                    color: Get.theme.colorScheme.secondary.withOpacity(0.10),
                                    borderRadius: BorderRadius.all(Radius.circular(20)),
                                  ),
                                  child: Text(
                                    "${controller.coupon.value.code}",
                                    style: TextStyle(color: Colors.grey, fontSize: 12),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                : Container();
          })
        ],
      ),
    );
  }

// Future<void> bottomSheetDialog(context) {
//   return showModalBottomSheet<void>(
//     context: context,
//     enableDrag: false,
//     isDismissible: false,
//     isScrollControlled: true,
//     builder: (BuildContext context) {
//       return WillPopScope(
//           onWillPop: () {
//             return;
//           },
//           child: Container(
//             height: 200,
//             color: Colors.white,
//             child: Container(
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.start,
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 mainAxisSize: MainAxisSize.min,
//                 children: <Widget>[
//                   Container(
//                     padding: EdgeInsets.only(left: 15, right: 15, top: 10, bottom: 10),
//                     width: double.infinity,
//                     color: Get.theme.colorScheme.secondary,
//                     child: Column(
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Text("Searching for provider...", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
//                         SizedBox(
//                           height: 3,
//                         ),
//                         Text("Please wait a while", style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w100))
//                       ],
//                     ),
//                   ),
//                   Container(padding: EdgeInsets.only(left: 15, top: 15), child: Text("Request Details", style: TextStyle(color: Colors.black.withOpacity(.7), fontSize: 16, fontWeight: FontWeight.w600))),
//                   Container(
//                     padding: EdgeInsets.only(left: 30, top: 10),
//                     child: Column(
//                       children: [
//                         Row(
//                           children: [
//                             Container(
//                               margin: EdgeInsets.only(right: 5),
//                               width: 10,
//                               height: 10,
//                               decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: Get.theme.colorScheme.secondary,
//                               ),
//                             ),
//                             Text("${_addToCartController.addToCartData.length} ${_addToCartController.addToCartData.length > 1 ? "Services".tr : "Service".tr}", style: TextStyle(color: Colors.grey, fontSize: 12)),
//                           ],
//                         )
//                       ],
//                     ),
//                   ),
//                   Container(
//                     padding: EdgeInsets.only(left: 30, top: 5),
//                     child: Column(
//                       children: [
//                         Row(
//                           children: [
//                             Container(
//                               margin: EdgeInsets.only(right: 5),
//                               width: 10,
//                               height: 10,
//                               decoration: BoxDecoration(
//                                 shape: BoxShape.circle,
//                                 color: Get.theme.colorScheme.secondary,
//                               ),
//                             ),
//                             Text("${_addToCartController.totalAmount().toStringAsFixed(3)} \$", style: TextStyle(color: Colors.grey, fontSize: 12))
//                           ],
//                         )
//                       ],
//                     ),
//                   ),
//                   GestureDetector(
//                     onTap: () {
//                       Navigator.pop(context);
//                     },
//                     child: Container(
//                       padding: EdgeInsets.only(right: 15, top: 15),
//                       child: Row(
//                         mainAxisAlignment: MainAxisAlignment.end,
//                         children: [
//                           Text(
//                             "cancel".tr,
//                             style: TextStyle(color: Colors.black, fontSize: 16),
//                           )
//                         ],
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ));
//     },
//   );
// }
}
