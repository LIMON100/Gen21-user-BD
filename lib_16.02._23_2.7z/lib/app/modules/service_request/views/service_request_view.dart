import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/src/simple/get_view.dart';
import '../../home/controllers/home_controller.dart';
import '../controllers/RequestController.dart';
import '../controllers/ServiceRequestController.dart';
import '../widgets/service_request_list_widget.dart';

class ServiceRequestsView extends GetWidget<ServiceRequestController> {
  // var isLoading = false.obs;

  @override
  Widget build(BuildContext context) {
    // final RequestController _requestController = Get.put(RequestController());
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "${controller.orderRequestResponse.value.eventData.service.length} Service Requests".tr,
          style: context.textTheme.headline6,
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        automaticallyImplyLeading: false,
        leading: new IconButton(
          icon: new Icon(Icons.arrow_back_ios, color: Get.theme.hintColor),
          onPressed: () => Get.back(),
        ),
        elevation: 0,
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // Container(
                  //   color: Colors.black,
                  //   child: Image.asset(
                  //     'assets/img/giphy.gif',
                  //     // fit: BoxFit.cover,
                  //     height: 100,
                  //     // width: 65,
                  //   ),
                  // ),
                  LinearProgressIndicator(
                    backgroundColor: Colors.red,
                    valueColor: new AlwaysStoppedAnimation<Color>(Colors.green),

                  ),

                  Container(
                    // alignment: Alignment.center,
                    padding: EdgeInsets.only(left: 20, right: 20, top: 20),
                    child:Text("Please wait, providers will receive requests soon.", textAlign: TextAlign.center, style: TextStyle(color: Get.theme.colorScheme.secondary, fontSize: 16, ))
                  ),
                  Obx(() {
                    // printWrapped("hhfasjfhbdjas in requestView ${controller.orderRequestPush.value.data.toString()}");
                    return controller.orderRequestResponse.value.eventData.coupon_data != null
                        ? Container(
                      child: Container(
                        width: double.infinity,
                        padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                        alignment: Alignment.center,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [Text("Applied Coupon: "), Text("${controller.orderRequestResponse.value.eventData.coupon_data.code}")],
                            ),
                            SizedBox(
                              height: 5,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [Text("Discount: "), controller.orderRequestResponse.value.eventData.coupon_data.discountType.toString() == "percent" ? Text("${controller.orderRequestResponse.value.eventData.coupon_data.discount}%") : Text("\$${controller.orderRequestResponse.value.eventData.coupon_data.discount}")],
                            ),
                          ],
                        ),
                      ),
                    )
                        : Container();
                  }),
                  Container(
                    child: ServiceRequestsListWidget(),
                    // child: Container(),
                  ),


                  // Container(
                  //   color: Get.theme.colorScheme.secondary,
                  //   height: 40,
                  //   child: GestureDetector(
                  //       onTap: () {
                  //         controller.resendRequest();
                  //       },
                  //       child: Text(
                  //         "Resend",
                  //         style: TextStyle(color: Colors.white),
                  //       )),
                  // )
                ],
              ),
            ),
          )
        ],
      ),
      bottomNavigationBar: Container(
        height: 50,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Obx(() {
            return controller.isLoading.value?
            Container(margin: EdgeInsets.only(right: 20, bottom: 10), child: CircularProgressIndicator(strokeWidth: 2))
                : GestureDetector(onTap: () async{
              controller.cancelOrder("${controller.orderRequestResponse.value.eventData.orderId}");
            }, child: Container(margin: EdgeInsets.only(right: 20, bottom: 10), padding: EdgeInsets.all(5), child: Text("Stop Request", style: TextStyle(color: Colors.grey),)));
          })
         ,
        ],
      )),
    );
  }

// @override
// void dispose() {
//   controller.closeRingTone();
//   super.dispose();
// }

}
