String predefinedCountryCode = "+88";
String countryCodeBd = "+88";
String countryCodeAu = "+61";
//eWay live url
// String eWayBaseUrl = "https://api.sandbox.ewaypayments.com/";
// String eWayDoneDoneUrl = "secure-au.sandbox.ewaypayments.com/sharedpage/sharedpayment/Result";

//eWay live url
String eWayBaseUrl = "https://api.ewaypayments.com/";
String eWayDoneDoneUrl = "secure.ewaypayments.com/sharedpage/sharedpayment/Result";
