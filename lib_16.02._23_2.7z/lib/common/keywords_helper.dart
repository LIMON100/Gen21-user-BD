class KeywordsHelper{
  static final String noImageUrl = "https://app.gen21.com.au/images/image_default.png";
}