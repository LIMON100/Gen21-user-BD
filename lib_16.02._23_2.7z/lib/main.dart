import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
// import 'package:flutter_stetho/flutter_stetho.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:internet_connection_checker/internet_connection_checker.dart';

import 'app/modules/global_widgets/no_internet_connection.dart';
import 'app/providers/firebase_provider.dart';
import 'app/providers/laravel_provider.dart';
import 'app/routes/app_routes.dart';
import 'app/routes/theme1_app_pages.dart';
import 'app/services/auth_service.dart';
import 'app/services/firebase_messaging_service.dart';
import 'app/services/global_service.dart';
import 'app/services/settings_service.dart';
import 'app/services/translation_service.dart';

void initServices() async {
  Get.log('starting services ...');
  await GetStorage.init();
  await Get.putAsync(() => TranslationService().init());
  await Get.putAsync(() => GlobalService().init());
  await Firebase.initializeApp();
  await Get.putAsync(() => AuthService().init());
  await Get.putAsync(() => LaravelApiClient().init());
  await Get.putAsync(() => FirebaseProvider().init());
  await Get.putAsync(() => SettingsService().init());
  Get.log('All services started...');
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  bool isInternetConnected = await InternetConnectionChecker().hasConnection;
  print("fklkaslkld $isInternetConnected");


  if (isInternetConnected) {
    await initServices();
    print("fklkaslkld 1");
  } else {
    print("fklkaslkld 2");
    // await Get.putAsync(() => SettingsService().init());

    // Get.toNamed(Routes.NO_INTERNET);
    // Navigator.push(context, Routes.NO_INTERNET))
  }

  // Future<bool> checkBaseUrl() async {
  //   bool data = await splashRepo.checkBaseUrl();
  //   print("sdnjfnja bool in splash provider $data");
  //   return data;
  // }
  // Stetho.initialize();
  runApp(
    isInternetConnected
        ? GetMaterialApp(
            title: Get.find<SettingsService>().setting.value.appName,
            initialRoute: Theme1AppPages.INITIAL,
            onReady: () async {
              print("fklkaslkld 3");

              await Get.putAsync(() => FireBaseMessagingService().init());
            },
            getPages: Theme1AppPages.routes,
            localizationsDelegates: [GlobalMaterialLocalizations.delegate],
            supportedLocales: Get.find<TranslationService>().supportedLocales(),
            translationsKeys: Get.find<TranslationService>().translations,
            locale: Get.find<SettingsService>().getLocale(),
            fallbackLocale: Get.find<TranslationService>().fallbackLocale,
            debugShowCheckedModeBanner: false,
            defaultTransition: Transition.cupertino,
            themeMode: Get.find<SettingsService>().getThemeMode(),
            theme: Get.find<SettingsService>().getLightTheme(),
            darkTheme: Get.find<SettingsService>().getDarkTheme(),
          )
        : GetMaterialApp(
            title: "No Internet Connection",
            initialRoute: Theme1AppPages.NO_INTERNET,
            getPages: Theme1AppPages.routes,
            // localizationsDelegates: [GlobalMaterialLocalizations.delegate],
            // supportedLocales: Get.find<TranslationService>().supportedLocales(),
            // translationsKeys: Get.find<TranslationService>().translations,
            // locale: Get.find<SettingsService>().getLocale(),
            // fallbackLocale: Get.find<TranslationService>().fallbackLocale,
            debugShowCheckedModeBanner: false,
            defaultTransition: Transition.cupertino,
            // themeMode: Get.find<SettingsService>().getThemeMode(),
            // theme: Get.find<SettingsService>().getLightTheme(),
            // darkTheme: Get.find<SettingsService>().getDarkTheme(),
          ),
  );


}
